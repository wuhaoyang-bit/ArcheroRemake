import"./modulepreload-polyfill-P2Xu9kJm.js";import{E as e,Gt as t,U as n,Xr as r,cn as i,dn as a,en as o,it as s,l as c,ot as l,rt as u,xr as d}from"./slime-eyes-config-CHbZBc5y.js";import{M as ee}from"./GLTFLoader-BBBIp9k9.js";import{c as te,n as f}from"./config-D37YhUm9.js";import{i as ne,n as re,o as ie}from"./progress-curve-editor-BTqeGAzL.js";/* empty css                           */import{l as p,n as m,o as h,r as g,s as _,t as v}from"./juice-particles-Ca4Yesi-.js";var y=Math.asin(.82),b=1/60,x=f.viewWidth,S=[{id:`custom`,title:`自定义曲线`,blurb:`手动编辑速度百分比`},{id:`linear`,title:`Linear`,blurb:`剩余 y=1−u`},{id:`easeOutQuad`,title:`OutQuad`,blurb:`剩余 y=(1−u)²`},{id:`easeOutCubic`,title:`OutCubic`,blurb:`剩余 y=(1−u)³`},{id:`easeOutExpo`,title:`OutExpo`,blurb:`剩余 y≈2^(−10u)`},{id:`smoothstep`,title:`smoothstep`,blurb:`剩余 y=1−t²(3−2t)`},{id:`dragHalfLife`,title:`指数阻力`,blurb:`剩余 y=2^(−u/Drel)`}],C=e=>document.getElementById(e);document.querySelector(`#app`).innerHTML=`
<header>
  <div>
    <small>ARCHERO · 汁液 lab</small>
    <h1>俯视外爆 · 曲线切换预览</h1>
    <p>圆盘出生、水平四周爆开；预设曲线同步控制速度与尺寸；自定义曲线单独控制速度。左侧切换曲线，并显示当前运动在曲线上的位置。</p>
  </div>
  <a href="./spider-viewer.html">蜘蛛预览器 ↗</a>
</header>
<div class="layout">
  <aside class="panel">
    <h2>控制</h2>
    <p class="hint">单视口预览。曲线图纵轴 = 剩余速度/尺寸比例 y。</p>
    <div class="bar">
      <button type="button" class="primary" id="burst">迸发</button>
      <button type="button" id="play" aria-pressed="false">播放</button>
      <button type="button" id="prev">◀</button>
      <button type="button" id="next">▶</button>
    </div>
    <label>帧 <output id="frameLabel">0</output>/<output id="frameMax">120</output></label>
    <input id="timeline" type="range" min="0" max="120" value="0" step="1">
    <div class="mono" id="timeReadout">t=0.000s</div>

    <h3>曲线</h3>
    <label>当前曲线
      <select id="curveSelect">${S.map(e=>`<option value="${e.id}">${e.title} — ${e.blurb}</option>`).join(``)}</select>
    </label>
    <div id="juice-speed-curve-editor" hidden></div>
    <div class="curve-box">
      <canvas id="curveCanvas" width="560" height="320"></canvas>
      <div class="curve-readout" id="curveReadout">—</div>
    </div>

    <h3>出生</h3>
    <label>命中后迸发时间 <output id="delayLabel">0.13</output> s<input id="delay" type="range" min="0" max="3" step="0.01" value="0.13"></label>
    <label>粒子数 <output id="countLabel">16</output>
      <input id="count" type="range" min="8" max="64" value="16" step="1"></label>
    <label>圆盘半径 <output id="radiusLabel">0.34</output>
      <input id="radius" type="range" min="0.05" max="1.2" value="0.34" step="0.01"></label>
    <label>发射高度偏移 <output id="heightLabel">0.10</output>（相对 aimHeight）
      <input id="height" type="range" min="-0.4" max="0.8" value="0.1" step="0.01"></label>

    <h3>初速（水平）</h3>
    <label>初速基准 <output id="speedLabel">4.0</output>
      <input id="speed" type="range" min="0" max="20" value="4" step="0.1"></label>
    <label>初速随机 ± <output id="speedJitterLabel">1.0</output>
      <input id="speedJitter" type="range" min="0" max="10" value="1" step="0.1"></label>

    <h3>尺寸（世界单位）</h3>
    <label>尺寸基准 <output id="sizeLabel">0.60</output>
      <input id="size" type="range" min="0.01" max="2" value="0.60" step="0.01"></label>
    <label>尺寸随机 ± <output id="sizeJitterLabel">0.08</output>
      <input id="sizeJitter" type="range" min="0" max="1" value="0.08" step="0.01"></label>

    <h3>寿命 / 阻力</h3>
    <label>寿命 s <output id="lifeLabel">1.80</output>
      <input id="life" type="range" min="0.35" max="2.5" value="1.8" step="0.05"></label>
    <label>指数阻力 Drel <output id="dragRelLabel">0.55</output>
      <input id="dragRel" type="range" min="0.1" max="1" value="0.55" step="0.05"></label>
    <p class="hint">每次点击「迸发」自动生成新的随机分布；逐帧回看保留当前这一波。</p>

    <h3>颜色 / 深度</h3>
    <label>汁液颜色（可吸色）
      <input id="color" type="color" value="#ffdd32"></label>
    <label class="inline"><input id="depthTest" type="checkbox" checked> 深度遮挡</label>
    <div class="tex">
      <img id="texPreview" src="./juice-lab/juice-mask.png" alt="mask" width="48" height="48">
      <code class="mono">白膜 × 颜色染色 · 单波瞬时</code>
    </div>
  </aside>
  <div class="stage-wrap">
    <div class="top">
      <h3 id="stageTitle">easeOutCubic</h3>
      <span class="mono" id="stageSub">剩余 y=(1−u)³</span>
    </div>
    <div class="stage" id="stage"></div>
    <div class="readout" id="readout">—</div>
  </div>
</div>`;var w=_(),T=c.map(e=>({...e}));function E(){return{speedCurve:T,delay:+C(`delay`).value,curve:C(`curveSelect`).value,count:+C(`count`).value,radius:+C(`radius`).value,height:+C(`height`).value,speed:+C(`speed`).value,speedJitter:+C(`speedJitter`).value,size:+C(`size`).value,sizeJitter:+C(`sizeJitter`).value,life:+C(`life`).value,dragRel:+C(`dragRel`).value,seed:w,color:C(`color`).value,depthTest:C(`depthTest`).checked}}function D(e,t){return g(t,{count:e.count,speed:e.speed,speedJitter:e.speedJitter,radius:e.radius,life:e.life,size:e.size,sizeJitter:e.sizeJitter,seed:e.seed})}async function O(){let c=C(`stage`),g=new d;g.background=new e(`#e5e5ca`);let O=new i,k=new ee({antialias:!0});k.setPixelRatio(Math.min(devicePixelRatio,2)),await k.init(),k.shadowMap.enabled=!0,k.shadowMap.type=1,c.replaceChildren(k.domElement),g.add(new l(16121829,11979372,1.7));let A=new n(16774350,1.6);A.position.set(-9,22,-8),A.castShadow=!0,A.shadow.mapSize.set(2048,2048),Object.assign(A.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:70}),g.add(A);let j=new t(new a(28,28),new o({color:14803397,roughness:1}));j.rotation.x=-Math.PI/2,j.position.y=-.015,j.receiveShadow=!0,g.add(j),g.add(new u(14,14,10593160,12895657));let M=(await ne.load()).create();M.userData.practiceTarget=`spider`;let N=new s;N.add(M),g.add(N);let P=ie(M),F={...te,hitKnockEnabled:0,hitRimEnabled:1,hitSquashEnabled:1,monsterScale:f.monsterScale,monsterHitSpeed:f.monsterHitSpeed},I=new re(N,[{id:`spider`,x:0,z:0}],8,8),L={x:0,z:1},R=await m.load(g),z=C(`curveCanvas`),ae=z.getContext(`2d`),B=[],V=0,H=0,U=!1,W=0;C(`curveSelect`).value=`easeOutCubic`;let G=new p(C(`juice-speed-curve-editor`),()=>T,e=>{T=e,Z()});function K(){let e=E();C(`juice-speed-curve-editor`).hidden=e.curve!==`custom`,G.render(),C(`delayLabel`).textContent=e.delay.toFixed(2),C(`countLabel`).textContent=String(e.count),C(`radiusLabel`).textContent=e.radius.toFixed(2),C(`heightLabel`).textContent=e.height.toFixed(2),C(`speedLabel`).textContent=e.speed.toFixed(1),C(`speedJitterLabel`).textContent=e.speedJitter.toFixed(1),C(`sizeLabel`).textContent=String(e.size),C(`sizeJitterLabel`).textContent=String(e.sizeJitter),C(`lifeLabel`).textContent=e.life.toFixed(2),C(`dragRelLabel`).textContent=e.dragRel.toFixed(2);let t=S.find(t=>t.id===e.curve);C(`stageTitle`).textContent=t.title,C(`stageSub`).textContent=t.blurb;let n=Math.ceil(Math.max(e.delay+e.life*1.12,F.hitSquashTime)/b);C(`timeline`).max=String(n),C(`frameMax`).textContent=String(n),C(`texPreview`).style.background=e.color}function q(){let{width:e,height:t}=c.getBoundingClientRect();if(e<2||t<2)return;k.setSize(e,t);let n=e/t,r=x,i=r/n;Object.assign(O,{left:-r/2,right:r/2,top:i/2,bottom:-i/2,near:.1,far:140}),O.updateProjectionMatrix(),O.position.set(0,24,0+24/Math.tan(y)),O.lookAt(0,0,0),O.updateMatrixWorld()}function J(){return new r(M.position.x,I.aimHeight(`spider`)+E().height,M.position.z)}function Y(e,t){if(e<0||B.length===0)return{u:0,y:1,alive:0,avgSpeed:0,avgSize:0,avgSpeed0:t.speed};let n=0,r=0,i=0,a=0,o=0,s=0;for(let c of B){if(e>=c.life)continue;let l=e/c.life,u=h(t.curve,l,t.dragRel,T);n++,r+=l,i+=u,a+=c.speed0*u,o+=c.s0*h(t.curve===`custom`?`easeOutCubic`:t.curve,l,t.dragRel),s+=c.speed0}return n?{u:r/n,y:i/n,alive:n,avgSpeed:a/n,avgSize:o/n,avgSpeed0:s/n}:{u:1,y:0,alive:0,avgSpeed:0,avgSize:0,avgSpeed0:t.speed}}function oe(e,t,n){let r=ae,i=z.width,a=z.height;r.clearRect(0,0,i,a),r.fillStyle=`#1a2216`,r.fillRect(0,0,i,a),r.strokeStyle=`#2f3a28`,r.lineWidth=1;for(let e=0;e<=4;e++){let t=36+(i-72)*e/4,n=36+(a-72)*e/4;r.beginPath(),r.moveTo(t,36),r.lineTo(t,a-36),r.stroke(),r.beginPath(),r.moveTo(36,n),r.lineTo(i-36,n),r.stroke()}let o=e=>36+e*(i-72),s=e.curve===`custom`?Math.max(1,...T.map(e=>e.progress/100)):1,c=e=>a-36-e/s*(a-72);r.strokeStyle=`#556348`,r.setLineDash([4,4]),r.beginPath(),r.moveTo(36,c(0)),r.lineTo(i-36,c(0)),r.stroke(),r.beginPath(),r.moveTo(36,c(1)),r.lineTo(i-36,c(1)),r.stroke(),r.setLineDash([]),r.strokeStyle=`#d9c17a`,r.lineWidth=2.4,r.beginPath();for(let t=0;t<=120;t++){let n=t/120,i=h(e.curve,n,e.dragRel,T),a=o(n),s=c(i);t===0?r.moveTo(a,s):r.lineTo(a,s)}r.stroke();let l=Math.min(1,Math.max(0,t)),u=Math.min(s,Math.max(0,n));r.strokeStyle=`#7eb8c4`,r.lineWidth=1,r.setLineDash([3,3]),r.beginPath(),r.moveTo(o(l),36),r.lineTo(o(l),a-36),r.stroke(),r.beginPath(),r.moveTo(36,c(u)),r.lineTo(i-36,c(u)),r.stroke(),r.setLineDash([]),r.fillStyle=`#e8ebdc`,r.beginPath(),r.arc(o(l),c(u),5,0,Math.PI*2),r.fill(),r.strokeStyle=`#1a4d57`,r.lineWidth=2,r.stroke(),r.fillStyle=`#9aa88a`,r.font=`12px ui-monospace, Menlo, sans-serif`,r.fillText(`u = age/life`,i-36-88,a-10),r.fillText(`y 剩余`,8,40);let d=E().speed;C(`curveReadout`).textContent=`u=${l.toFixed(3)} · y=${u.toFixed(3)} · v≈${(d*u).toFixed(2)}（按中位初速） · 曲线 ${e.curve}`}function X(){w=_(),I.reset(),I.hit(`spider`,L,F),P.animation.preview(`Hitted`,0),M.updateMatrixWorld(!0),V=Math.max(0,E().delay/b),B=D(E(),J()),H=0,C(`timeline`).value=`0`,Z()}function Z(){K();let e=E(),t=H*b;V=e.delay/b,C(`frameLabel`).textContent=String(H),C(`timeline`).value=String(H),C(`timeReadout`).textContent=`t=${t.toFixed(3)}s · emit@${(V*b).toFixed(3)}s · 水平外爆 · 无重力`,I.reset(),I.hit(`spider`,L,F);let n=e.delay;V=n/b,I.update(Math.min(t,n),F),B=D(e,J());let r=t-n;R.clear();let i={...F,juiceEnabled:1,juiceCount:e.count,juiceSpeed:e.speed,juiceSpeedJitter:e.speedJitter,juiceRadius:e.radius,juiceLife:e.life,juiceSize:e.size,juiceSizeJitter:e.sizeJitter,juiceSpeedCurve:T,juiceCurve:v.indexOf(e.curve),juiceDragRel:e.dragRel,juiceColor:parseInt(e.color.slice(1),16),juiceDepthTest:+!!e.depthTest};r>=0&&R.emit(J(),i,r,w),I.update(Math.max(0,t-n),F);let a=P.animation.durations().Hitted;P.animation.preview(`Hitted`,Math.min(t*F.monsterHitSpeed,a)),M.updateMatrixWorld(!0),q(),R.prepare(O,i);let o=Y(r,e);C(`readout`).textContent=`alive ${o.alive} · ⌀u ${o.u.toFixed(3)} · ⌀y ${o.y.toFixed(3)} · ⌀v ${o.avgSpeed.toFixed(2)} · ⌀s ${o.avgSize.toFixed(3)} · curve ${e.curve}`,oe(e,o.u,o.y),q(),k.render(g,O)}function Q(e){if(U=e,C(`play`).textContent=e?`暂停`:`播放`,C(`play`).setAttribute(`aria-pressed`,String(e)),e){cancelAnimationFrame(W);let e=()=>{if(!U)return;let t=+C(`timeline`).max;H>=t?Q(!1):(H+=1,Z(),W=requestAnimationFrame(e))};W=requestAnimationFrame(e)}else cancelAnimationFrame(W)}C(`burst`).onclick=()=>{Q(!1),X()},C(`play`).onclick=()=>{!U&&H>=+C(`timeline`).max&&(H=0,Z()),Q(!U)},C(`prev`).onclick=()=>{Q(!1),H=Math.max(0,H-1),Z()},C(`next`).onclick=()=>{Q(!1),H=Math.min(+C(`timeline`).max,H+1),Z()},C(`timeline`).oninput=()=>{Q(!1),H=+C(`timeline`).value,Z()};let $=[`delay`,`count`,`radius`,`height`,`speed`,`speedJitter`,`size`,`sizeJitter`,`life`];for(let e of[...$,`dragRel`,`color`,`curveSelect`,`depthTest`])C(e).addEventListener(`input`,()=>{K(),$.includes(e)&&(B=D(E(),J())),Z()}),C(e).addEventListener(`change`,()=>{K(),(e===`curveSelect`||e===`depthTest`)&&Z()});window.addEventListener(`keydown`,e=>{e.target.matches(`input,select,textarea,button`)||(e.code===`Space`&&(e.preventDefault(),C(`play`).click()),e.code===`ArrowLeft`&&(e.preventDefault(),C(`prev`).click()),e.code===`ArrowRight`&&(e.preventDefault(),C(`next`).click()))}),new ResizeObserver(()=>Z()).observe(c),X(),Object.assign(window,{__JUICE_LAB__:{seek:e=>{Q(!1),H=e,Z()},snapshot:()=>({frame:H,emitFrame:V,params:E(),juice:R.snapshot()})}})}O().catch(e=>{document.body.insertAdjacentHTML(`beforeend`,`<p style="color:#f88;padding:20px">加载失败：${e.message}</p>`),console.error(e)});